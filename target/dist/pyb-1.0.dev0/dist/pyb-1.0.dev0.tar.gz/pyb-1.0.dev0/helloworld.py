import sys

def helloworld(out):
    out.write("Hello world from python project! :)\n")